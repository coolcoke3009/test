
	function show_POP(ji_num, jb_idx, ji_tname, jb_sort, img_name, jf_idx, useUTF) { 

		var imgObj = new Image(); 
		imgObj.src = "../../data/"+ji_tname+"/"+jb_sort+"/"+img_name; 

		var img_w = imgObj.width;
		var img_h = imgObj.height;
		var screen_width = screen.width;
		var screen_height = screen.height;
		var winw, winh, Vimg_w, Vimg_h;


		if (img_w > (screen_width-256))  {
			Vimg_w = (screen_width-239);
			winw	 = parseInt((screen_width - Vimg_w - 17) / 2);
		} else {
			Vimg_w = parseInt(img_w+17);
			winw	 = parseInt((screen_width - Vimg_w) / 2);
		}

		if (img_h > (screen_height-256)) {
			Vimg_h = parseInt(img_h * (Vimg_w/img_w));
			if (Vimg_h > (screen_height-256))	Vimg_h = (screen_height-256);
			winh	 = parseInt((screen_height - Vimg_h - 40) / 2)-20;
		} else {
			Vimg_h = parseInt(img_h);
			winh	 = parseInt((screen_height - Vimg_h) / 2)-20;
		}
		

		var opt = 'toolbar=no,resizable=yes,scrollbars=yes,location=no,resize=no,menubar=no,';
		opt=opt+'status=yes,directories=no,copyhistory=0,';
		opt=opt+'width='+Vimg_w+',height='+Vimg_h+',top='+winh+',left='+winw; 


		var targetSTR = "../../Jsource/Jboard/include/img_pop.asp?ji_num="+ji_num+"&jb_idx="+jb_idx;
		targetSTR +="&jb_sort="+jb_sort+"&jf_idx="+jf_idx;
		targetSTR +="&img_width="+img_w+"&img_height="+img_h;
		targetSTR +="&screen_width="+screen_width;
		if (useUTF != '')	{
			targetSTR +='&jb_file='+encodeURL(img_name);
		} else {
			targetSTR +='&jb_file='+img_name;
		}
		window.open(targetSTR, 'jsSize', opt);

	} 




	function show_subNext(ji_num, jb_idx, ji_tname, jb_sort, img_name, jf_idx, useUTF) { 

		var imgObj = new Image(); 
		if (useUTF != '')	{
			imgObj.src = "../../data/"+ji_tname+"/"+jb_sort+"/"+encodeURL(img_name);
		} else {
			imgObj.src = "../../data/"+ji_tname+"/"+jb_sort+"/"+img_name; 
		}
		
		var img_w = imgObj.width;
		var img_h = imgObj.height;
		var screen_width = screen.width;
		var screen_height = screen.height;
		var winw, winh, Vimg_w, Vimg_h;


		if (img_w > (screen_width-256))  {
			Vimg_w = (screen_width-239);
			winw	 = parseInt((screen_width - Vimg_w - 17) / 2);
		} else {
			Vimg_w = parseInt(img_w+17);
			winw	 = parseInt((screen_width - Vimg_w) / 2);
		}

		if (img_h > (screen_height-256)) {
			Vimg_h = parseInt(img_h * (Vimg_w/img_w));
			if (Vimg_h > (screen_height-256))	Vimg_h = (screen_height-256);
			winh	 = parseInt((screen_height - Vimg_h - 40) / 2)-20;
		} else {
			Vimg_h = parseInt(img_h);
			winh	 = parseInt((screen_height - Vimg_h) / 2)-20;
		}


		var opt = 'toolbar=no,resizable=yes,scrollbars=yes,location=no,resize=no,menubar=no,';
		opt=opt+'status=yes,directories=no,copyhistory=0,';
		opt=opt+'width='+Vimg_w+',height='+Vimg_h+',top='+winh+',left='+winw; 


		var targetSTR = "../../Jsource/Jboard/include/img_subNext.asp?ji_num="+ji_num+"&jb_idx="+jb_idx;
		targetSTR +="&jb_sort="+jb_sort;
		targetSTR +="&img_width="+img_w+"&img_height="+img_h;
		targetSTR +="&screen_width="+screen_width;
		window.open(targetSTR, 'subNext', opt);

	} 




	function show_reSize(ji_num, jb_idx, ji_tname, jb_sort, img_name, find_sort, find_name, find_title, find_content, find_text, s_idx, e_idx, reSizeRemain, useUTF) { 

		var imgObj = new Image(); 
		if (useUTF != '')	{
			imgObj.src = "../../data/"+ji_tname+"/"+jb_sort+"/"+encodeURL(img_name);
		} else {
			imgObj.src = "../../data/"+ji_tname+"/"+jb_sort+"/"+img_name; 
		}

		var img_w = imgObj.width;
		var img_h = imgObj.height;
		var screen_width = screen.width;
		var screen_height = screen.height;
		var winw, winh, Vimg_w, Vimg_h;


		if (img_w > (screen_width-256))  {
			Vimg_w = (screen_width-239);
			winw	 = parseInt((screen_width - Vimg_w - 17) / 2);
		} else {
			Vimg_w = parseInt(img_w+17);
			winw	 = parseInt((screen_width - Vimg_w) / 2);
		}

		if (img_h > (screen_height-256)) {
			Vimg_h = parseInt(img_h * (Vimg_w/img_w));
			if (Vimg_h > (screen_height-256))	Vimg_h = (screen_height-256);
			winh	 = parseInt((screen_height - Vimg_h - 40) / 2)-20;
		} else {
			Vimg_h = parseInt(img_h);
			winh	 = parseInt((screen_height - Vimg_h) / 2)-20;
		}


		var opt = 'toolbar=no,resizable=yes,scrollbars=yes,location=no,resize=no,menubar=no,';
		opt=opt+'status=yes,directories=no,copyhistory=0,';
		opt=opt+'width='+Vimg_w+',height='+Vimg_h+',top='+winh+',left='+winw; 


		var targetSTR = "../../Jsource/Jboard/include/img_reSize.asp?ji_num="+ji_num+"&jb_idx="+jb_idx+"&jb_sort="+jb_sort;
		targetSTR +="&find_sort="+find_sort+"&find_name="+find_name;
		targetSTR +="&find_title="+find_title+"&find_content="+find_content;
		targetSTR +="&find_text="+find_text;
		targetSTR +="&s_idx="+s_idx+"&e_idx="+e_idx+"&reSizeRemain="+reSizeRemain;
		targetSTR +="&img_width="+img_w+"&img_height="+img_h;
		targetSTR +="&screen_width="+screen_width;
		window.open(targetSTR, 'ShowReSize', opt);

	}




	function noticeLink(relative_location, notice_folder, ji_num, jb_sort, jb_idx, jb_ref) {

		var clf = document.noticeLinkForm;
		var target = 'JnoticeFrame';
		parent.name = target;

		clf.jb_ref.value = jb_ref;
		clf.screen_width.value = screen.width;

		if (notice_folder == '') {
			targetSTR = relative_location + "Jsource/Jboard/content.asp?ji_num="+ji_num
			targetSTR = targetSTR+"&jb_sort="+jb_sort+"&jb_idx="+jb_idx;
		} else {
			targetSTR = relative_location + "webpage/"+notice_folder+"/content.asp?ji_num="+ji_num
			targetSTR = targetSTR+"&jb_sort="+jb_sort+"&jb_idx="+jb_idx;
		}

		clf.target = target;
		clf.action = targetSTR;
		clf.method = 'post';
		clf.submit();

	}
