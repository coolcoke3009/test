


	document.getElementById("sub_menu_001").style.display = 'block';
	document.getElementById("sub_course_001").src = '../images/sub_down.gif';
	document.getElementById("sub_vaginal_001").src = '../images/sub_minus.gif';
	document.getElementById("sub_title_001").style.fontWeight='bold';



	var Trans = false;

	function submit_ok(check_count, ji_upnum) {
		var check_count, ji_num, ji_upnum;
		var ma = document.mailing_form;
		var select_check;

		if(check_count == "0") {

			if ( ma.mail_group.value == "" ) {
				alert("���ϱ׷��� �����ϼž� ���� �� �ֽ��ϴ�.");
				ma.mail_group.focus();
				return false;	
			}

		}


		for(i=0; i < ma.jm_tag.length; i++) {
			if(ma.jm_tag[i].checked) { 
				select_check=ma.jm_tag[i].value; 
				break;
			}
		}

		if(!select_check) { 
			alert("[��������]�� �������ּ���.");
			return false;
		}


		if ( ma.jm_title.value == "" ) {
			alert("[����]�� �Է����ּ���");
			ma.jm_title.focus();
			return false;
		}



		if(check_count == "view") {
			page_location = "include/Jmailing_view.asp";

				ma.action = page_location;
				ma.target = '_balnk'


				ma.submit();


				Trans = true;

		} else {

			page_location = "Jmailing_pro.asp";

			answer1 = confirm("�����Ͻ� ������ �����Ͻðڽ��ϱ�?");

			if(answer1 == true) {
				ma.action = page_location;

				if (Trans == false) {
				ma.submit();
				}

				Trans = true;
			}
			else {
				alert("��ҵǾ����ϴ�.");
			}

		}
	
	}




	function LCategory_Select(Searchitem){
		var search_mail_group = document.mailing_form.mail_group.value;
		var targetSTR = "Jmailing.asp?mail_Group="+search_mail_group;
		window.location.href = targetSTR;
	}



	function readonly_check() {
	var ma = document.mailing_form;

		if (ma.jm_tag[0].value == "mail_form" && ma.jm_tag[0].checked == true) {
			ma.jm_content.readOnly = 1;
		}
		else {
		ma.jm_content.readOnly = 0;
		}
	}


