<!--
function tick() {
  var month,date,hours, minutes, seconds, ap;
  var intYear,intDate,intMon,intHours, intMinutes, intSeconds;
  var today;

  today = new Date();

  intYear = today.getFullYear();  
  intDate = today.getDate();
  intMon = today.getMonth()+1;
  intHours = today.getHours();
  intMinutes = today.getMinutes();
  intSeconds = today.getSeconds();

  	month = intMon;

  if (intDate < 10) {
  	date = "0"+intDate;
  } else {
  	date = intDate;
  }
  if (intHours == 0) {
     hours = "12:";
     ap = "����";

  } else if (intHours < 12) { 
     hours = intHours+":";
     ap = "����";

  } else if (intHours == 12) {
     hours = "12:";
      ap = "����";

  } else {
     intHours = intHours - 12
     hours = intHours + ":";
     ap = "����";
  }

  if (intMinutes < 10) {
     minutes = "0"+intMinutes+":";
  } else {
     minutes = intMinutes+":";
  }

  if (intSeconds < 10) {
     seconds = "0"+intSeconds;
  } else {
     seconds = intSeconds;
  } 

  timeString = intYear + "�� " + month +"�� "+ date +"�� " + ap + " " +hours+minutes+seconds;

  Clock.innerHTML = timeString;

  window.setTimeout("tick();", 100);
}

window.onload = tick; 
-->
