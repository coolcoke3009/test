

	document.getElementById("sub_menu_000").style.display = 'block';
	document.getElementById("sub_course_000").src = '../images/sub_down.gif';
	document.getElementById("sub_vaginal_000").src = '../images/sub_minus.gif';
	document.getElementById("sub_title_000").style.fontWeight='bold';
