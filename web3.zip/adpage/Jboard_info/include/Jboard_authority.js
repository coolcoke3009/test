

// ���� ����

	document.getElementById("sub_course_003").src = '../images/sub_down.gif';
	document.getElementById("sub_title_003").style.fontWeight='bold';

// ���� ��




//���Ѹ���Ʈ ����


	function all_check() {      
		
		var len = document.pagesize_form.chk.length;
		var chk = document.pagesize_form.chk; 

		if (len != '0')	{
		
			for ( var i=2;i<len; i++ ) {
				
				chk[i].checked = !chk[i].checked;
				tr_check(i);
			
			}
		}

	}



	function tr_check(num) {   
		
		var i = num; 
		var pf = document.pagesize_form;

		pf.ji_listAu[i].checked = !pf.ji_listAu[i].checked;
		pf.ji_readAu[i].checked = !pf.ji_readAu[i].checked;
		pf.ji_writeAu[i].checked = !pf.ji_writeAu[i].checked;
		pf.ji_replyAu[i].checked = !pf.ji_replyAu[i].checked;
		pf.ji_commentAu[i].checked = !pf.ji_commentAu[i].checked;
		pf.ji_downAu[i].checked = !pf.ji_downAu[i].checked;
		pf.ji_recommAu[i].checked = !pf.ji_recommAu[i].checked;
		pf.ji_iconAu[i].checked = !pf.ji_iconAu[i].checked;
		pf.ji_pictureAu[i].checked = !pf.ji_pictureAu[i].checked;

	}



	function listAu_check() {      
		
		var len = document.pagesize_form.ji_listAu.length;
		var ji_listAu = document.pagesize_form.ji_listAu; 

		if (len != '0')	{
		
			for ( var i=2;i<len; i++ ) {
				ji_listAu[i].checked = !ji_listAu[i].checked;
			}
		}

	}


	function readAu_check() {      
		
		var len = document.pagesize_form.ji_readAu.length;
		var ji_readAu = document.pagesize_form.ji_readAu; 

		if (len != '0')	{
		
			for ( var i=2;i<len; i++ ) {
				ji_readAu[i].checked = !ji_readAu[i].checked;
			}
		}

	}


	function writeAu_check() {      
		
		var len = document.pagesize_form.ji_writeAu.length;
		var ji_writeAu = document.pagesize_form.ji_writeAu; 

		if (len != '0')	{
		
			for ( var i=2;i<len; i++ ) {
				ji_writeAu[i].checked = !ji_writeAu[i].checked;
			}
		}

	}


	function replyAu_check() {      
		
		var len = document.pagesize_form.ji_replyAu.length;
		var ji_replyAu = document.pagesize_form.ji_replyAu; 

		if (len != '0')	{
		
			for ( var i=2;i<len; i++ ) {
				ji_replyAu[i].checked = !ji_replyAu[i].checked;
			}
		}

	}


	function commentAu_check() {      
		
		var len = document.pagesize_form.ji_commentAu.length;
		var ji_commentAu = document.pagesize_form.ji_commentAu; 

		if (len != '0')	{
		
			for ( var i=2;i<len; i++ ) {
				ji_commentAu[i].checked = !ji_commentAu[i].checked;
			}
		}

	}


	function downAu_check() {      
		
		var len = document.pagesize_form.ji_downAu.length;
		var ji_downAu = document.pagesize_form.ji_downAu; 

		if (len != '0')	{
		
			for ( var i=2;i<len; i++ ) {
				ji_downAu[i].checked = !ji_downAu[i].checked;
			}
		}

	}


	function recommAu_check() {      
		
		var len = document.pagesize_form.ji_recommAu.length;
		var ji_recommAu = document.pagesize_form.ji_recommAu; 

		if (len != '0')	{
		
			for ( var i=2;i<len; i++ ) {
				ji_recommAu[i].checked = !ji_recommAu[i].checked;
			}
		}

	}


	function iconAu_check() {      
		
		var len = document.pagesize_form.ji_iconAu.length;
		var ji_iconAu = document.pagesize_form.ji_iconAu; 

		if (len != '0')	{
		
			for ( var i=2;i<len; i++ ) {
				ji_iconAu[i].checked = !ji_iconAu[i].checked;
			}
		}

	}


	function pictureAu_check() {      
		
		var len = document.pagesize_form.ji_pictureAu.length;
		var ji_pictureAu = document.pagesize_form.ji_pictureAu; 

		if (len != '0')	{
		
			for ( var i=2;i<len; i++ ) {
				ji_pictureAu[i].checked = !ji_pictureAu[i].checked;
			}
		}

	}



function sendit_1(){

	if (confirm("ȸ���� ���Ѽ����� �����Ͻðڽ��ϱ�?")) {
		
	}
	else {
		alert("������ ��ҵǾ����ϴ�.");
		return false;
	}

	document.pagesize_form.submit();
}


//���Ѹ���Ʈ ��
