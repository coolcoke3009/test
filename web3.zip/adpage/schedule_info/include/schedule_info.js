


// ���� ����


	function allblur() {
		for (i = 0; i < document.links.length; i++)
			document.links[i].onfocus = document.links[i].blur;
	}

	//window.onload = allblur;





	function ShowProgress(si_upload) {

		if (si_upload == "1") {

			strAppVersion = navigator.appVersion; 

			winstyle = "dialogWidth=385px; dialogHeight:150px; center:yes"; 
			window.showModelessDialog("../inc/show_progress.asp?nav=ie", null, winstyle);
		}	
		
	}



	if (document.getElementById("sub_menu_006") != undefined) {
		document.getElementById("sub_menu_006").style.display = 'block';
		document.getElementById("sub_course_006").src = '../../adpage/images/sub_down.gif';
		document.getElementById("sub_vaginal_006").src = '../../adpage/images/sub_minus.gif';
		document.getElementById("sub_title_006").style.fontWeight='bold';
	}


// ���� ��






// ������ ����

	function pgsize() {
		document.pagesize_form.submit();       
	}
	
	function focus_on(form_name) {
		form_name.style.borderColor='#FF0000';
		form_name.style.backgroundColor='#ffeeee'
	}

	function blur_on(form_name) {
		form_name.style.borderColor='';
		form_name.style.backgroundColor='';
	}



	function changeYear(){
		var sf = document.write_form
		var sc_year = sf.sc_year.value;
		var sc_month = sf.sc_month.value;
		var sc_day = sf.sc_day.value;
		var targetSTR = "schedule.asp?sc_year="+sc_year+"&sc_month="+sc_month+"&sc_day="+sc_day;
		window.location.href = targetSTR;
	}







	function img_loading()	{
		var wf = document.write_form;
		var len = document.write_form.IMAGEPREVIEW.length;

		if (len > 0) {

			for ( var i=0; i<len; i++ ) {

				if(wf.IMAGEPREVIEW[i].width >= 32) {
					wf.IMAGEPREVIEW[i].width = 32;
				}
				if(wf.IMAGEPREVIEW[i].height >= 34)	{
					wf.IMAGEPREVIEW[i].height = 34;
				}

			}

		} else {
		
			if(wf.IMAGEPREVIEW.width >= 32) {
				wf.IMAGEPREVIEW.width = 32;
			}
			if(wf.IMAGEPREVIEW.height >= 34)	{
				wf.IMAGEPREVIEW.height = 34;
			}

		}

	}




	function previewImage()	{
		var j = 0
		
		var wf = document.write_form;
		var len = document.write_form.IMAGEPREVIEW.length;

		if (len > 0) {

			for ( var i=0; i<len; i++ ) {

				j = j + 1

				fileStr_1 = eval('wf.original_file_'+ j).value
				fileStr_2 = eval('wf.modify_file_'+ j).value
				
				var str = fileStr_2, ext, strExt;
				ext = str.lastIndexOf(".");
				strExt = str.substring(ext+1);

				if (fileStr_1 == "" && fileStr_2 == "")	{
					wf.IMAGEPREVIEW[i].src="../images/img_SmallNoImage.gif";
				} else {

					if (fileStr_2 != "" )	{

						if (strExt == "swf") {
							wf.IMAGEPREVIEW[i].src="../images/img_SmallFlashFile.gif";
						} else {
							wf.IMAGEPREVIEW[i].src = fileStr_2;
						}
					
					}

				}

				
				var imgObj = new Image(); 
				imgObj.src = eval('wf.shell_'+ j).value
					
				if (imgObj.width > 20) {
					alert('�������� ���� 20pixel�� ���� �� �����ϴ�. \n\n�������� �ٿ���� �ٶ��ϴ�.');
					return false;
				}

				if (imgObj.height > 20) {
					alert('�������� ���� 20pixel�� ���� �� �����ϴ�. \n\n�������� �ٿ���� �ٶ��ϴ�.');
					return false;
				}

			}

		} else {
		
				fileStr_1 = eval('wf.original_file_1').value
				fileStr_2 = eval('wf.modify_file_1').value

				var str = fileStr_2, ext, strExt;
				ext = str.lastIndexOf(".");
				strExt = str.substring(ext+1);

				if (fileStr_1 == "" && fileStr_2 == "")	{
					wf.IMAGEPREVIEW.src="../images/img_SmallNoImage.gif";
				} else {

					if (strExt == "swf") {
						wf.IMAGEPREVIEW.src="../images/img_SmallFlashFile.gif";
					} else {
						wf.IMAGEPREVIEW.src = fileStr_2;
					}

				}


				var imgObj = new Image(); 
				imgObj.src = eval('wf.shell_1').value
					
				if (imgObj.width > 120) {
					alert('�������� ���� 120pixel�� ���� �� �����ϴ�. \n\n�������� �ٿ���� �ٶ��ϴ�.');
					return false;
				}

				if (imgObj.height > 15) {
					alert('�������� ���� 15pixel�� ���� �� �����ϴ�. \n\n�������� �ٿ���� �ٶ��ϴ�.');
					return false;
				}



		}
		
	}


	function image_check(){
		var j = 0
		var regExt =/(\.[^\.]*$)/;
		var wf = document.write_form;
		var len = document.write_form.IMAGEPREVIEW.length;


		if (len > 0) {

			for ( var i=0; i<len; i++ ) {

				j = j + 1

				frm = eval('wf.modify_file_'+ j);
				fileStr = frm.value;

				if (fileStr != "")	{
					filename = fileStr.replace(regExt, "");
									
					strExt = fileStr.replace(filename,"").toLowerCase();
									
					if (strExt != ".jpg" && strExt != ".jpeg" && strExt != ".gif" && strExt != ".png" && strExt != ".swf") {
						alert("�����Ͻ� ������ ���ε� �Ͻ� �� �����ϴ�.");								 
						wf.IMAGEPREVIEW[i].src="../images/img_SmallNoImage.gif";
						return;
					}

				}

			}


		} else {
		
				frm = eval('wf.modify_file_1');
				fileStr = frm.value;

				if (fileStr != "")	{
					filename = fileStr.replace(regExt, "");
									
					strExt = fileStr.replace(filename,"").toLowerCase();
									
					if (strExt != ".jpg" && strExt != ".jpeg" && strExt != ".gif" && strExt != ".png") {
						alert("�����Ͻ� ������ ���ε� �Ͻ� �� �����ϴ�.");
						wf.IMAGEPREVIEW.src="../images/no_HpSpec.gif";
						return false;
					}

				}

		}

		previewImage();
	}

// ������ ��




//  ������/����ϵ�� ����



	var Trans = false; 
	function sendit_2(si_upload, ji_upnum, mode) {

		var wf = document.write_form;
		var regExt =/(\.[^\.]*$)/;

		if (mode == "write") {
		 	var submitFlag = 0;
		} else {
			var submitFlag = 1;
		}
	

		if (previewImage() == false) return false;

		page_location = "date_"+mode+"_pro.asp";

		ShowProgress(si_upload);
		wf.action = page_location;
		wf.submit();


		Trans = true;

	}





	function write_re() {
			document.write_form.reset();
	}




//  ������/����ϵ�� ����









//  ������/����ϸ���Ʈ ����




	function show_img(ji_tname, jb_sort, img_name, update_code, img_width, img_height) {

		var winw = (screen.width - img_width) / 2;
		var winh = (screen.height - img_height) / 2;
		
		var opt = 'toolbar=no,resizable=no,scrollbars=no,location=no,resize=no,menubar=no,directories=no,copyhistory=0,';
		opt=opt+'width='+img_width+',height='+img_height+',top= '+winh+',left = '+winw; 
		
		var page_location = 'include/img_view.asp?ji_tname='+ji_tname+'&jb_sort='+jb_sort+'&img_name='+img_name;
		page_location += '&update_code='+update_code+'&img_width='+img_width+'&img_height='+img_height;

		window.open(page_location, 'new_window', opt); 

	}





  function search_2() {
		var sf = document.search_form

		if (sf.find_text.value == "") {
			alert("[�˻���]�� �Է��� �ּ���.");
			sf.find_text.focus();
			return false;
		}
  }



	function all_check() {
		
		var chk = document.pagesize_form.chk;
		var len = chk.length;

		if (len > 0) {
		
			for ( var i=0;i<len; i++ ) chk[i].checked = !chk[i].checked;
		} else {
			chk.checked = !chk.checked;
		}

	}


	function check_all(bool) {      
		
		var chk = document.pagesize_form.chk; 
		var len = chk.length;

		if (len > 0) {
			if (bool) {          
				for(i=0; i<len; i++) {
					chk[i].checked = true;
				}
				return
			} else {
				for(i=0; i<len; i++) {
					chk[i].checked = false;
				}
				return    
			}
		} else {
			if (bool) {
				chk.checked = true;
				return
			} else {
				chk.checked = false;
				return
			}
		}
	}






	function check_modify(pagesize, gotopage)	{
		var pf = document.pagesize_form;
		var len = pf.chk.length;
		var submitFlag = 0;

		if (len > 0) {
			for(i=0; i<len; ++i) {
				if(pf.chk[i].name == 'chk') {
					if(pf.chk[i].checked == true) {
						submitFlag = 1;
					break;
					}
				}
			}
		} else {
			if(pf.chk.name == 'chk') {
				if(pf.chk.checked == true) {
					submitFlag = 1;
				}
			}
		}

		if(submitFlag){
			if (confirm("�����Ͻ� �����͸� �����Ͻðڽ��ϱ�?")) {
				var	page_location = "date_write.asp?pagesize="+pagesize+"&gotopage="+gotopage;
				page_location = page_location+"&mode=modify&da_sort="+pf.da_sort.value;
				pf.action = page_location;
				pf.submit();
				return;
			}
			else {
				alert("�����۾��� ��ҵǾ����ϴ�.");
			return;
			}

		}
		else{
			alert("������ �����ʾҽ��ϴ�."); 
		return;
		}
	}






	function check_delete(pagesize, gotopage)	{
		var pf = document.pagesize_form;
		var len = pf.chk.length;
		var submitFlag = 0;

		if (len > 0) {
			for(i = 0; i<len; ++i) {
				if(pf.chk[i].name == 'chk') {
					if(pf.chk[i].checked == true) {
						submitFlag = 1;
					break;
					}
				}
			}
		} else {
			if(pf.chk.name == 'chk') {
				if(pf.chk.checked == true) {
					submitFlag = 1;
				}
			}
		}

		if(submitFlag){

			if (confirm("�����Ͻ� �����͸� ���� �����Ͻðڽ��ϱ�?")) {
			page_location="date_delete_pro.asp?pagesize="+pagesize+"&gotopage="+gotopage+"&da_sort="+pf.da_sort.value;
			pf.action = page_location;
			pf.submit();
			return;
			}
			else {
			alert("�����۾��� ��ҵǾ����ϴ�.");
			return;
			}

		}
		else{
			alert("������ �����ʾҽ��ϴ�."); 
		return;
		}
	}



//  ������/����ϸ���Ʈ ��
