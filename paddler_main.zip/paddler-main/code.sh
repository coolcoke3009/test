#!/bin/bash
code --no-sandbox --user-data-dir=roror

