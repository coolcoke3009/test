


// ID/PASSWORD ã�� ����


	function addDash(obj) {
		var sNoDashNumber = "" ;
		sNoDashNumber	= removeDash(obj);
		var iLen		= getLeng(sNoDashNumber);

		if (event.keyCode != 8) {
			switch (iLen) {
				case 0:
					break;
				case 1:
					break;
				case 2:
					break;
				case 3:
					break;
				case 4:
					break;
				case 5:
					break;
				case 6:
				case 7:
				case 8:
				case 9:
					if (sNoDashNumber.substring(0,2) == "02")	{
						obj.value = sNoDashNumber.substring(0,2) + "-" + sNoDashNumber.substr(2,3) + "-" + sNoDashNumber.substr(5,4) ;
						break;
					}
				case 10:
					if (sNoDashNumber.substring(0,2) == "02")	{
						obj.value  = sNoDashNumber.substring(0,2) + "-" + sNoDashNumber.substr(2,4) + "-" + sNoDashNumber.substr(6,4) ;
					} else {
						obj.value  = sNoDashNumber.substring(0,3) + "-" + sNoDashNumber.substr(3,3) + "-" + sNoDashNumber.substr(6,4) ;
					}
					break;
				case 11:
					if (sNoDashNumber.substring(0,2) == "02")	{
						obj.value  = sNoDashNumber.substring(0,2) + "-" + sNoDashNumber.substr(2,4) + "-" + sNoDashNumber.substr(6,4) ;
					} else {
						obj.value  = sNoDashNumber.substring(0,3) + "-" + sNoDashNumber.substr(3,4) + "-" + sNoDashNumber.substr(7,4) ;
					}
					break;
			}
		}
	}


	function removeDash(obj) {

		var sNoDashNumber = "";
		var i = 0;															
		
		for (i = 0; i < obj.value.length; i++) {
			if ((obj.value).charAt(i) != "-") {
				sNoDashNumber += (obj.value).charAt(i);
			}
		}

		return sNoDashNumber;
	}


	function getLeng(sMessage) {
		var iCount = 0 ;
		for (var i = 0; i < sMessage.length; i++) {
			if ( sMessage.charCodeAt(i) > 127) {
				iCount += 2;
			}
			else {
				iCount++;
			}
		}
		return iCount;
	}




	function onlyNumber() {
		if((event.keyCode<48)||(event.keyCode>57))
		event.returnValue=false;
	}



	function find_check(ji_prevContent) {

		var fi = document.find_form

		if(fi.me_name.value == "") {
			 alert("�̸��� �Է����ּ���.");
			 fi.me_name.focus();
			 return;
			 }


		if (ji_prevContent == 0) {

			if(fi.me_jumin1.value == "") {
				alert("�ֹε�Ϲ�ȣ�� �Է����ּ���.");
				fi.me_jumin1.focus();
				return;
			}
			if(fi.me_jumin2.value == "") {
				alert("�ֹε�Ϲ�ȣ�� �Է����ּ���.");
				fi.me_jumin2.focus();
				return;
			}

		} else if (ji_prevContent == 1)	{

			if(fi.me_tel.value == "") {
				alert("��ȭ��ȣ�� �Է����ּ���.");
				fi.me_tel.focus();
				return;
			}

		} else if (ji_prevContent == 2)	{

			if(fi.me_hp.value == "") {
				alert("�ڵ�����ȣ�� �Է����ּ���.");
				fi.me_hp.focus();
				return;
			}

		} else if (ji_prevContent == 3)	{

			if(fi.me_email.value == "") {
				alert("E-Mail�� �Է����ּ���.");
				fi.me_email.focus();
				return;
			} else {
			
				var tempchar = 0;
				for (i=0;i<fi.me_email.value.length; i++ ) {
						 temp = fi.me_email.value.charAt(i);
					if (temp == "@" || temp ==".") {
						tempchar++; 
					}
				}
				if (tempchar < 2) {
					alert("�̸����� �߸��Է��ϼ̽��ϴ�.");
					fi.me_email.focus();
					return;
				}
			
			
			}

		} else if (ji_prevContent == 4)	{

			if(fi.me_hint.value == "") {
				alert("ȸ�����Խ� ������ ������ �������ּ���.");
				fi.me_hint.focus();
				return;
			}

			if(fi.me_HintAn.value == "") {
				alert("�ۼ��Ͻ� �亯�� �Է����ּ���.");
				fi.me_HintAn.focus();
				return;
			}

		} else {

			if(fi.me_nickName.value == "") {
				alert("�г����� �Է����ּ���.");
				fi.me_nickName.focus();
				return;
			}

		}

		fi.submit();

	}



	function moves1() {
		if(document.find_form.me_jumin1.value.length==6)
		   document.find_form.me_jumin2.focus();
	}


	function moves2()	{
		if(document.find_form.me_jumin2.value.length==7)
		document.find_form.me_email.focus();
	}

// ID/PASSWORD ã�� ��
