

	function FlashPlayer(FlashName, width, height) {
		document.write('<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="'+ width +'" height="'+ height +'">');
		document.write('<param name="movie" value="'+ FlashName +'">');
		document.write('<param name="quality" value="high">');
		document.write('<param name=WMode value="Transparent">');
		document.write('<embed src="'+ FlashName +'" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="'+ width +'" height="'+ height +'"></embed>');
		document.write('</object>');
	}


	function bannerLink(baRelative_location, ba_idx, ba_url) {

		window.open(baRelative_location+"Jsource/Jbanner/banner_openSite.asp?ba_idx="+ba_idx+"&ba_url="+ba_url+"",'','');
	
	}
	
