
	function focusStart() {
			
		if (document.post_form.DongName.value == '') {
			setTimeout("document.post_form.DongName.focus();",170);
		} else {
			setTimeout("document.post_form.SelectAddress.focus();",170);
		}

	}


	function sendit_1() {

		var pf = document.post_form;

		if (pf.DongName.value == "") {
			alert("��/��/���� �̸��Է��� �Է����ּ���.");
			pf.DongName.focus();
			return false;
		}
	
	}


	function FindAddress(form_name, zipcode_1, zipcode_2, address, width, height) {
		var form_name, zipcode_1, zipcode_2, address, targetSTR
		var width, height, str;

		targetSTR = "../../Jsource/JPostSearch/PostSearch.asp?form_name="+form_name+"&zipcode_1="+zipcode_1;
		targetSTR = targetSTR+"&zipcode_2="+zipcode_2+"&address="+address;

		SLB(targetSTR, 'iframe', width, width, false, true);
		
	}




	function SelectAddressandChange() {
		var pf = document.post_form;
		var strAddress = pf.SelectAddress[pf.SelectAddress.selectedIndex].value;
		
		var strArray;
		strArray = strAddress.split(",");
		strAddress = "[" + strArray[0] + "] " + strArray[1] + " " + strArray[2] + " " + strArray[3];
		strremainder_addr = strArray[4];

		pf.SelectAddress[pf.SelectAddress.selectedIndex].text = strAddress;
		pf.remainder_addr.value = strremainder_addr;
		pf.remainder_addr.focus();

	}



	function CompleteSearch(form_name, zipcode_1, zipcode_2, address) {
		var pf_2 = document.post_form;

			nIndex = pf_2.SelectAddress.selectedIndex;
			
			if (nIndex != 0){
				strAddress = pf_2.SelectAddress.options[nIndex].text + " " + pf_2.remainder_addr.value;
			} else {
				alert("�ּҸ� �������ּ���");
				pf_2.SearchAddress.focus();
				return;
			}
			
			DisplayAddress(strAddress,form_name, zipcode_1, zipcode_2, address);
			parent.SLB();

		if  (pf_2.remainder_addr.value == "")	{
			alert("��/���̳� ������ ��Ȯ�ϰ� �Է����ֽʽÿ�.");
			pf_2.remainder_addr.focus();
			return;
		}

	}



	function DisplayAddress(strAddress, form_name, zipcode_1, zipcode_2, address) {

		var str = strAddress, deuk, temp;
		var zipcode_1, zipcode_2, address;
		zipcode_1 = eval('parent.document.'+form_name+'.'+zipcode_1);
		zipcode_2 = eval('parent.document.'+form_name+'.'+zipcode_2);
		address	 = eval('parent.document.'+form_name+'.'+address);

		deuk = str.lastIndexOf("]");
		temp = str.substring(deuk+2);

		zipcode_1.value = str.substr(1,3);
		zipcode_2.value = str.substr(5,3);
		address.value = temp;

	}

