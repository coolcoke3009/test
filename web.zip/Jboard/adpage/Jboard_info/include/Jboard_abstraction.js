

// ���� ����


	function allblur() {
		for (i = 0; i < document.links.length; i++)
			document.links[i].onfocus = document.links[i].blur;
	}

	//window.onload = allblur;



	function reset() {
		for (i = 0; i < document.forms.length; i++)
			document.forms[i].value = document.forms[i].reset();
	}



	function onlyNumber() {
		if((event.keyCode<48)||(event.keyCode>57))
		event.returnValue=false;
	}


	document.getElementById("sub_course_003").src = '../images/sub_down.gif';
	document.getElementById("sub_title_003").style.fontWeight='bold';

// ���� ��



// ������� ����



	function OnClickTR_1(){

		if (document.getElementById("Jboard_abstraction_write_tr_1").style.display == "none") {
			document.getElementById("Jboard_abstraction_write_tr_1").style.display = "block";
		}	else {
			document.getElementById("Jboard_abstraction_write_tr_1").style.display = "none";
		}

	}

	function OnClickTR_2(){

		if (document.getElementById("Jboard_abstraction_write_tr_2").style.display == "none") {
			document.getElementById("Jboard_abstraction_write_tr_2").style.display = "block";
		}	else {
			document.getElementById("Jboard_abstraction_write_tr_2").style.display = "none";
		}

	}






	function source_view() {

	var af = document.Jboard_abstraction_form;
	var a, b, c, d, e, f, g, h, i, j, img, bae, eun, mang, relative_location;
	var g0 = 0;
	var g1 = 0;
	var g2 = 0;
	var g3 = 0;
	var g4 = 0;
	var g5 = 0;
	var g6 = 0;
	var g7 = 0;
	var g8 = 0;
	var g9 = 0;
	var g10 = 0;
	var g11 = 0;
	var g12 = 0;
	var g13 = 0;

		a = af.A.value;
		b = af.B.value;
		c = af.C[0].value + af.C[1].value;
		d = af.D.value;
		e = af.E.value;


		f = af.F.value;

		if (af.G[0].checked == true) g0 = parseInt(af.G[0].value);
		if (af.G[1].checked == true) g1 = parseInt(af.G[1].value);
		if (af.G[2].checked == true) g2 = parseInt(af.G[2].value);
		if (af.G[3].checked == true) g3 = parseInt(af.G[3].value);
		if (af.G[4].checked == true) g4 = parseInt(af.G[4].value);
		if (af.G[5].checked == true) g5 = parseInt(af.G[5].value);
		if (af.G[6].checked == true) g6 = parseInt(af.G[6].value);
		if (af.G[7].checked == true) g7 = parseInt(af.G[7].value);
		if (af.G[8].checked == true) g8 = parseInt(af.G[8].value);
		if (af.G[9].checked == true) g9 = parseInt(af.G[9].value);
		if (af.G[10].checked == true) g10 = parseInt(af.G[10].value);
		if (af.G[11].checked == true) g11 = parseInt(af.G[11].value);
		if (af.G[12].checked == true) g12 = parseInt(af.G[12].value);
		if (af.G[13].checked == true) g13 = parseInt(af.G[13].value);

		g = g0 + g1 + g2 + g3 + g4 + g5 + g6 + g7 + g8 + g9 + g10 + g11 + g12 + g13;

		img = af.shell_1.value;
		bae = img.length;
		eun = img.lastIndexOf("\\")+1;	
		mang = bae - eun;

		if (af.H.checked == true) {
			h = parseInt(af.H.value);
		} else {
			h = '';
		}

		i = af.I.value;
		j = af.J.value;
		k = img.substr(eun,mang);

		relative_location = af.relative_location.value;

		
		af.ji_abstraction.value = "<!-- #include file='"+relative_location+"Jsource/Jnotice/list.asp' -->\n<%'������������ �ߺ����� ���� ��Ŭ���� �ѹ��� ����ϼŵ� �˴ϴ�.%>\n\n<%=Notice(\""+a+"\",\""+b+"\",\""+c+"\",\""+d+"\",\""+e+"\",\""+f+"\",\""+g+"\",\""+h+"\",\""+i+"\",\""+j+"\",\""+k+"\",\""+relative_location+"\")%>";
	}





	function registAbstraction(ji_name, ji_insert) {

	var jaf = document.Jboard_abstraction_form;
	var checkbox_check;

		if (jaf.C[0].value == '') {	
			alert("���⸮��Ʈ ���̸� �Է����ּ���");
			jaf.C[0].focus();
			return;
		}

		if (jaf.D.value == '') {	
			alert("����Ʈ ��ϼ��� �Է����ּ���");
			jaf.D.focus();
			return;
		}


		if (jaf.D.value == 0) {	
			alert("����Ʈ ��ϼ��� 1�̻��̿��� �մϴ�.");
			jaf.D.focus();
			return;
		}


		for(i=0; i < jaf.G.length; i++) {
			if(jaf.G[i].checked) { 
				checkbox_check=jaf.G[i].value; 
				break;
			}
		}

		if(!checkbox_check) { 
			alert("��¿ɼ��� �������ּ���.");
			return;
		}

		if (ji_insert == '2')	{
			if (jaf.J.value == '') {	
				alert("����� �Խù��� ��µ� ������ �������ּ���.");
				findFolder('Jboard_abstraction_form','J')
				return;
			}
		} else {		
			if (jaf.ji_AbsFolder.value == '') {	
				alert("����� �Խù��� ��µ� ������ �������ּ���.");
				findLocation('Jboard_abstraction_form','ji_AbsFolder');
				return;
			}
		}

		if (confirm(ji_name+"�� �Խù� ���⼳�������� �����Ͻðڽ��ϱ�?")) {

		}
		else {
			alert("������ ��ҵǾ����ϴ�.");
			return;
		}

	jaf.action = "Jboard_abstraction_modify_pro.asp";
	jaf.method = "post";
	jaf.target = "";
	jaf.submit();

	}

// ������� ��


