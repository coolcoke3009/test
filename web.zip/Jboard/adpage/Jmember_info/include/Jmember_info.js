


// ���� ����


	function allblur() {
		for (i = 0; i < document.links.length; i++)
			document.links[i].onfocus = document.links[i].blur;
	}

	//window.onload = allblur;


	function reset() {
		for (i = 0; i < document.forms.length; i++)
			document.forms[i].value = document.forms[i].reset();
	}


  function onlyNumber() {
    if ( ((event.keyCode < 48) || (57 < event.keyCode)) && (45 != event.keyCode) && 46 != event.keyCode ) 
    event.returnValue=false;
  }


	if (document.getElementById("sub_menu_001") != undefined) {
		document.getElementById("sub_menu_001").style.display = 'block';
		document.getElementById("sub_course_001").src = '../../adpage/images/sub_down.gif';
		document.getElementById("sub_vaginal_001").src = '../../adpage/images/sub_minus.gif';
		document.getElementById("sub_title_001").style.fontWeight='bold';
	}

// ���� ��
















// MODIFY �� ����


	if(window.XMLHttpRequest) {
		xmlRequest = new XMLHttpRequest();
	} else { 
		xmlRequest = new ActiveXObject("Microsoft.XMLHTTP");
	} 

	function ajax_skinColor() {

		var jiwf = document.Jmember_info_modify_form;
		
		ji_skinname = jiwf.ji_skinname.value;


		var url = "include/ajax_skinColorPro.asp?ji_skinname="+escape(ji_skinname);
		xmlRequest.open("GET",url,true);
		xmlRequest.onreadystatechange = skinColor;
		xmlRequest.send(null);

	}

	function skinColor() {
				
		if (xmlRequest.readyState ==4){
			var ji_skinColor = xmlRequest.responseText;
			document.getElementById("ji_skinColor").innerHTML = ji_skinColor;
		}
	}



	function OnClickTR_2(){

		if (document.getElementById("Jmember_info_write_tr_2").style.display == "none") {
			document.getElementById("Jmember_info_write_tr_2").style.display = "block";
			document.getElementById("Jmember_info_write_tr_3").style.display = "block";
			document.getElementById("Jmember_info_write_tr_4").style.display = "block";
			document.getElementById("Jmember_info_write_tr_5").style.display = "block";
			document.getElementById("Jmember_info_write_tr_6").style.display = "none";
			document.getElementById("Jmember_info_write_tr_7").style.display = "none";
		}	else {
			document.getElementById("Jmember_info_write_tr_2").style.display = "none";
			document.getElementById("Jmember_info_write_tr_3").style.display = "none";
			document.getElementById("Jmember_info_write_tr_4").style.display = "none";
			document.getElementById("Jmember_info_write_tr_5").style.display = "none";
		}

	}


	function OnClickTR_3(){

		if (document.getElementById("Jmember_info_write_tr_6").style.display == "none") {
			document.getElementById("Jmember_info_write_tr_6").style.display = "block";
			document.getElementById("Jmember_info_write_tr_7").style.display = "block";
			document.getElementById("Jmember_info_write_tr_2").style.display = "none";
			document.getElementById("Jmember_info_write_tr_3").style.display = "none";
			document.getElementById("Jmember_info_write_tr_4").style.display = "none";
			document.getElementById("Jmember_info_write_tr_5").style.display = "none";
		}	else {
			document.getElementById("Jmember_info_write_tr_6").style.display = "none";
			document.getElementById("Jmember_info_write_tr_7").style.display = "none";
		}

	}


	function OnClickTR_4(){

		document.getElementById("Jmember_info_write_tr_6").style.display = "none";
		document.getElementById("Jmember_info_write_tr_7").style.display = "none";
		document.getElementById("Jmember_info_write_tr_2").style.display = "none";
		document.getElementById("Jmember_info_write_tr_3").style.display = "none";
		document.getElementById("Jmember_info_write_tr_4").style.display = "none";
		document.getElementById("Jmember_info_write_tr_5").style.display = "none";

	}



	function opt_ins_modi(n){
		var obj1,obj2,len

		if (n == "1"){
			obj1 = document.Jmember_info_modify_form.opt1_size;
			obj2 = document.Jmember_info_modify_form.opt1_list;
		}else{//n=="2"
			obj1 = document.Jmember_info_modify_form.opt2_size;
			obj2 = document.Jmember_info_modify_form.opt2_list;
		}

		if(obj1.value.length < 1) {
			alert("�ɼǳ����� �Է��Ͽ��� �մϴ�.");
			obj1.focus();
			return;
		}

		len = obj2.length;
		obj2.length = len+1;
		obj2.options[len].value = obj1.value;
		obj2.options[len].text = obj1.value;
		obj1.value="";
		obj1.focus();
	}



	function opt_del_modi(n){

			if (n == "1"){
				var obj = document.Jmember_info_modify_form.opt1_list;
			}else{//n=="2"
				var obj = document.Jmember_info_modify_form.opt2_list;
			}
			var now_seq = obj.selectedIndex;//���� ����Ʈ ��ü
			if (now_seq==-1){
				alert("�ɼ��� �����ϼ���.");
				return;
			}
			obj.options[obj.selectedIndex]=null;
	}




	function registInfo(ji_name){

		var jiwf = document.Jmember_info_modify_form;
		var listArray = new Array(jiwf.opt1_list,jiwf.opt2_list);
		var i, j

		var FormLimit = 4000
		var PrefaceVar = new String
		var RearVar = new String


    var select_check1;
		var len = jiwf.ji_skinColor.length;

		if (len > 0) {		

			for(i=0; i < len; i++) {
				if(jiwf.ji_skinColor[i].checked) { 
					select_check1=jiwf.ji_skinColor[i].value; 
					break;
				}
			}

		} else {
			if(jiwf.ji_skinColor.checked) { 
				select_check1=jiwf.ji_skinColor.value; 
			}
		}

    if(!select_check1) { 
      alert("��Ų�÷��� ������ �ּ���.");
      return;
    }

		if (jiwf.ji_writePo.value == '') {	
			alert("��������Ʈ�� �Է����ּ��� \n\n���Խ� ����Ʈ ������ ���ٷ��� 0�� �Է��մϴ�.");
			jiwf.ji_writePo.focus();
			return;
		}

		if (jiwf.ji_width[0].value == '') {	
			alert("������ ���̸� �Է����ּ���");
			jiwf.ji_width[0].focus();
			return;
		}

		if (jiwf.ji_width[0].value == 0) {	
			alert("������ ���̴� 0���� Ŀ���մϴ�.");
			jiwf.ji_width[0].focus();
			return;
		}



		if (jiwf.ji_listChoice[0].checked == true && jiwf.ji_writeChoice[0].checked == false) {	
			jiwf.ji_writeChoice[0].checked = true;
		}

		if (jiwf.ji_listChoice[5].checked == true && jiwf.ji_writeChoice[5].checked == false) {	
			jiwf.ji_writeChoice[5].checked = true;
		}


		if (confirm(ji_name+" ���������� �����Ͻðڽ��ϱ�?")) {

			for (i=0;i<2;i++){
					
				for(j=0;j<listArray[i].length;j++){
					listArray[i].options[j].selected = true;
				}
			}



			PrefaceVar = jiwf.ji_preface.value

			if (PrefaceVar.length > FormLimit) {
				jiwf.ji_preface.value = PrefaceVar.substr(0, FormLimit)
				PrefaceVar = PrefaceVar.substr(FormLimit)

				while (PrefaceVar.length > 0) {
					var PrefaceTextArea = document.createElement("TEXTAREA")
					PrefaceTextArea.name = "ji_preface"
					PrefaceTextArea.value = PrefaceVar.substr(0, FormLimit)
					jiwf.appendChild(PrefaceTextArea)

					PrefaceVar = PrefaceVar.substr(FormLimit)
				}
			}

			
			RearVar = jiwf.ji_rear.value    

			if (RearVar.length > FormLimit) {
				jiwf.ji_rear.value = RearVar.substr(0, FormLimit)
				RearVar = RearVar.substr(FormLimit)

				while (RearVar.length > 0) {
					var RearTextArea = document.createElement("TEXTAREA")
					RearTextArea.name = "ji_rear"
					RearTextArea.value = RearVar.substr(0, FormLimit)
					jiwf.appendChild(RearTextArea)

					RearVar = RearVar.substr(FormLimit)
				}
			}


			jiwf.action = "Jmember_info_modify_pro.asp";
			jiwf.method = "post";
			jiwf.target = "";
			jiwf.submit();

		} else {
			alert("������ ��ҵǾ����ϴ�.");
			return;
		}

	}



	function stipulationCheck() {

		var jiwf = document.Jmember_info_modify_form;
	
		if (jiwf.ji_listChoice[0].checked == true) {	
			jiwf.ji_writeChoice[0].checked = true;
		} else {
			jiwf.ji_writeChoice[0].checked = false;		
		}

	}


	function nickNamePrint() {

		var jiwf = document.Jmember_info_modify_form;
	
		if (jiwf.ji_listChoice[4].checked == true) {	
			alert('�α��� �� ���� �Խù��� ����̵Ǹ�, �г����� ��ϵ��� ������ \'�̸�\'���� ��ü ��µ˴ϴ�. \n\n����, ȸ�������� �ߺ� ���� ȸ���������� �켱�� �˴ϴ�.')
		}

	}


	function juminPrint() {

		var jiwf = document.Jmember_info_modify_form;
	
		if (jiwf.ji_listChoice[5].checked == true) {	
			jiwf.ji_writeChoice[5].checked = true;
		} else {
			jiwf.ji_writeChoice[5].checked = false;		
		}

	}



// MODIFY �� ��




//ȸ������Ʈ ����





	function pgsize() {
		document.list_form.submit();       
	}





	function all_check() {
		
		var chk = document.list_form.chk;

		if (chk == undefined) {
			alert("��ϵ� ȸ���� �����ϴ�."); 
			return;
		} else {

			var len = chk.length;

			if (len > 0) {		
				for ( var i=0;i<len; i++ ) {
					if (chk[i].checked)	{
						chk[i].checked = false;
					}	else {
						chk[i].checked = true;
					}	
				}
			} else {
				if (chk.checked)	{
					chk.checked = false;
				}	else {
					chk.checked = true;
				}	
			}

		}

	}




	function check_all(bool) {      
		
		var chk = document.list_form.chk; 

		if (chk == undefined) {
			alert("��ϵ� ȸ���� �����ϴ�."); 
			return;
		} else {

			var len = chk.length;

			if (len > 0) {
				if (bool) {          
					for(i=0; i<len; i++) {
						chk[i].checked = true;
					}
					return
				} else {
					for(i=0; i<len; i++) {
						chk[i].checked = false;
					}
					return    
				}
			} else {
				if (bool) {
					chk.checked = true;
					return
				} else {
					chk.checked = false;
					return
				}
			}
		}

	}





	function doBlink() {

		var blink = document.getElementsByTagName("BLINK");

		for (var i=0; i < blink.length; i++) {
			blink[i].style.visibility = blink[i].style.visibility == "" ? "hidden" : "" 
		}
		
	}


	function startBlink() {
		setInterval("doBlink()",2000)
	}





	function sms(pagesize, gotopage)	{

		var lf = document.list_form;

		if (lf.chk == undefined) {
			alert("��ϵ� ȸ���� �����ϴ�."); 
			return;
		} else {
			
			
			var len = lf.chk.length;
			var submitFlag = 0;

			if (len > 0) {
				for(i=0; i<len; ++i) {
					if(lf.chk[i].name == 'chk') {
						if(lf.chk[i].checked == true) {
							submitFlag = 1;
						break;
						}
					}
				}
			} else {
				if(lf.chk.name == 'chk') {
					if(lf.chk.checked == true) {
						submitFlag = 1;
					}
				}
			}

			if(submitFlag){
			lf.action="../sms/sms_send.asp?pagesize="+pagesize+"&gotopage="+gotopage;
			lf.submit();
			return;
			}
			else{
				alert("������ �����ʾҽ��ϴ�."); 
			return;
			}
		}

	}


	
	function paper(pagesize, gotopage)	{

		var lf = document.list_form;
		
		if (lf.chk == undefined) {
			alert("��ϵ� ȸ���� �����ϴ�."); 
			return;
		} else {

			var len = lf.chk.length;
			var submitFlag = 0;

			if (len > 0) {
				for(i=0; i<len; ++i) {
					if(lf.chk[i].name == 'chk') {
						if(lf.chk[i].checked == true) {
							submitFlag = 1;
						break;
						}
					}
				}
			} else {
				if(lf.chk.name == 'chk') {
					if(lf.chk.checked == true) {
						submitFlag = 1;
					}
				}
			}

			if(submitFlag){
			lf.action="../paper/paper_write.asp?pagesize="+pagesize+"&gotopage="+gotopage;
			lf.submit();
			return;
			}
			else{
				alert("������ �����ʾҽ��ϴ�."); 
			return;
			}
		}

	}



	function mailing(pagesize, gotopage, ji_email)	{

		var lf = document.list_form;
		
		if (lf.chk == undefined) {
			alert("��ϵ� ȸ���� �����ϴ�."); 
			return;
		} else {
				
			var len = lf.chk.length;
			var submitFlag = 0;

			if (len > 0) {
				for(i=0; i<len; ++i) {
					if(lf.chk[i].name == 'chk') {
						if(lf.chk[i].checked == true) {
							submitFlag = 1;
						break;
						}
					}
				}
			} else {
				if(lf.chk.name == 'chk') {
					if(lf.chk.checked == true) {
						submitFlag = 1;
					}
				}
			}

			if(submitFlag){


				if (ji_email == "1" && confirm("Outlook ���Ϲ߼��� �ѹ��� 30���� ���Ϸ� �߼� �����մϴ�!")) {
					targetSTR="../Jmailing/outlook_mailing.asp?pagesize="+pagesize+"&gotopage="+gotopage;


				} else if (ji_email == "0") {

					targetSTR="../jmailing/jmailing.asp?pagesize="+pagesize+"&gotopage="+gotopage;

				}	else {
					alert("���Ϲ߼� �۾��� ��ҵǾ����ϴ�.");
				return;
				}

				lf.action = targetSTR;
				lf.submit();
				return;

			} else {
				alert("������ �����ʾҽ��ϴ�."); 
			return;
			}
		}

	}





	function class_modify(cl_class, pagesize, gotopage)	{

		var lf = document.list_form;

		if (lf.chk == undefined) {
			alert("��ϵ� ȸ���� �����ϴ�."); 
			return false;
		} else {

			var len = lf.chk.length;
			var submitFlag = 0;


			if (len > 0) {
				for(i=0; i<len; ++i) {
					if(lf.chk[i].name == 'chk') {
						if(lf.chk[i].checked == true) {
							submitFlag = 1;
						break;
						}
					}
				}
			} else {
				if(lf.chk.name == 'chk') {
					if(lf.chk.checked == true) {
						submitFlag = 1;
					}
				}
			}

			if(submitFlag){

				if (confirm("�����Ͻ� ȸ��(��)�� ����� �����Ͻðڽ��ϱ�?")) {
				targetSTR="include/class_up.asp?cl_class="+cl_class+"&pagesize="+pagesize+"&gotopage="+gotopage;
				lf.action = targetSTR;
				lf.submit();
				return;
				}
				else {
				alert("������ ��ҵǾ����ϴ�.");
				return false;
				}

			}
			else {
				alert("������ �����ʾҽ��ϴ�.");
				lf.cl_class.value = '';
				return false;
			}
		}

	}



	function check_delete(pagesize, gotopage) {

		var lf = document.list_form;

		if (lf.chk == undefined) {
			alert("��ϵ� ȸ���� �����ϴ�."); 
			return;
		} else {

			var len = lf.chk.length;
			var submitFlag = 0;
			var answer1, answer2

			if (len > 0) {
				for(i=0; i<len; ++i) {
					if(lf.chk[i].name == 'chk') {
						if(lf.chk[i].checked == true) {
							submitFlag = 1;
						break;
						}
					}
				}
			} else {
				if(lf.chk.name == 'chk') {
					if(lf.chk.checked == true) {
						submitFlag = 1;
					}
				}
			}

			if(submitFlag){

				answer1 = confirm("�����Ͻ� ȸ���� �����Ͻðڽ��ϱ�?");
				if(answer1 == true) {
					answer2 = confirm("������ ȸ���� ������ ������ �Ұ��մϴ�. \n\n�׷��� �����Ͻðڽ��ϱ�?");
				}	
			
				if(answer2 == true) {
					var	targetSTR = "Jmember_delete_pro.asp?pagesize="+pagesize+"&gotopage="+gotopage;
					lf.method = 'post';
					lf.action = targetSTR;
					lf.submit();
					return;
				
				} else {
					alert("��ҵǾ����ϴ�.");
					return;
				}

			} else {
				alert("������ �����ʾҽ��ϴ�."); 
				return;
			}
		}
	}



	function changeCategory(active) {
		
		var lf = document.list_form
	

		if(active == "cl_class") {

			lf.select_FindText.style.display = 'block';
			lf.input_FindText.style.display = 'none';
			lf.find_text2.focus();

		} else {

			lf.input_FindText.style.display = 'block';
			lf.select_FindText.style.display = 'none';
			lf.find_text1.focus();

		}

	}


  function search() {
		var s = document.list_form
	
		if (s.find_sort.value != "cl_class")	{

			if (s.find_text1.value == "") {
				alert("[�˻���]�� �Է����ּ���.");
				s.find_text1.focus();
				return false;
			}

		}
  }


//ȸ������Ʈ ��




//ȸ���󼼺��� ����




	function numOnly(obj,frm,isCash){

		if (event.keyCode == 9 || event.keyCode == 37 || event.keyCode == 39) return;
		var returnValue = "";
		for (var i = 0; i < obj.value.length; i++){
			if (obj.value.charAt(i) >= "0" && obj.value.charAt(i) <= "9"){
				returnValue += obj.value.charAt(i);
			}else{
				returnValue += "";
			}
		}
		if (isCash){
			obj.value = cashReturn(returnValue);
			return;
		}
		obj.focus();
		obj.value = returnValue;

	}


	function cashReturn(numValue){

		var cashReturn = "";
		for (var i = numValue.length-1; i >= 0; i--){
			cashReturn = numValue.charAt(i) + cashReturn;
			if (i != 0 && i%3 == numValue.length%3) cashReturn = "," + cashReturn;
		}
		
		return cashReturn;
	}




	function show_img(img_name, img_w, img_h) { 

		var Vimg_w, Vimg_h, Vscrollbar, Vresizable
		var winw = (screen.width - img_w) / 2;
		var winh = (screen.height - img_h) / 2;

		if (img_w > 1024 || img_h > 768) {
			if (img_w > 1024)	{
				Vimg_w = 924;
			} else {
				Vimg_w = parseInt(img_w) + 18;
			}
			
			Vimg_h = 668;
			Vresizable = 'yes';
			Vscrollbar = 'yes';
			
		} else {
			Vimg_w = img_w;
			Vimg_h = img_h;
			Vresizable = 'no';
			Vscrollbar = 'no';
		}

		var opt = 'toolbar=no,resizable='+Vresizable+',scrollbars='+Vscrollbar+',location=no,resize=no,menubar=no,';
		opt=opt+'directories=no,copyhistory=0,';
		opt=opt+'width='+Vimg_w+',height='+Vimg_h+',top='+winh+',left='+winw; 

		window.open('../inc/img_view.asp?file='+img_name+'&img_width='+img_w+'&img_height='+img_h, '', opt);

	}





  function modifyPoint() {
		var cf = document.content_form
	
		if (cf.me_point.value == "") {
			alert("[����Ʈ]�� �Է��� �ּ���.");
			cf.me_point.focus();
			return;
		}

		cf.method = 'post';
		cf.action = "point_modify_pro.asp";
		cf.submit();

  }


//ȸ���󼼺��� ��
